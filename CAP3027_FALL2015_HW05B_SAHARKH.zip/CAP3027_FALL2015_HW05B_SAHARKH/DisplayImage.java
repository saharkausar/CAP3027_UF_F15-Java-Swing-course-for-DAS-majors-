import java.awt.BasicStroke;
import java.awt.Component;
import java.awt.Graphics2D;
import java.awt.Color;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.Line2D;
import java.awt.image.BufferedImage;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.SwingUtilities;

public class DisplayImage
{
	private static final int WIDTH = 401;
	private static final int HEIGHT = 401;

	public static void main(String[] args)
    {
		SwingUtilities.invokeLater(new Runnable()
        {
			public void run() {
				createAndShowGUI();
			}
		});
	}
	private static void createAndShowGUI()
    {
		JFrame frame = new ImageFrame(WIDTH, HEIGHT);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);		
	}
}	

class ImageFrame extends JFrame
{
    // Constructor
    // Initialize the variables
	private BufferedImage img;
	private Graphics2D plant2D;
	private ImageIcon icon;
	private JLabel label;
	private Random rand = new Random();
	private Stem[] stemObjs;
	private Color[] pigment;
	private BasicStroke[] strokes;
	
	// Sets up the frame's attributes and displays the menu
	public ImageFrame(int width, int height)
    {
        //frame attributes
		this.setTitle("CAP 3027 2015 - HW05B - Sahar Hussain");
		this.setSize(width, height);	
		
		img = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
		
		//adds a menu to the frame
		addMenu();
	}

	private void addMenu() {		
		
        // File Menu Option Display
		JMenu fileMenu = new JMenu("File");
		
		// Creates a JMenuItem for Directed Random Walk plant for the JMenu File if the user perform a random plant walk simulation
        
		JMenuItem drawItem = new JMenuItem("Directed Random Walk Plant");
		drawItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				new Thread( new Runnable() {
					public void run() {
						draw(promt_Stems(), promt_Steps(), promt_TransProb(), promt_RotIncr(), promt_Growth(), promt_Colors(),promt_Colors());
                        // Some testing animations
					//	draw(10, 70, .5f, .9f, 2, 0xFFFF0000, 0xFF0000FF);
                        
					}
				}).start();
			}
		});
		fileMenu.add(drawItem);
		
		// Creates a JMenuItem for the JMenu File if the user wishes to exit the program
		JMenuItem exitItem = new JMenuItem("Exit");
		exitItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				System.exit(0);
			}
		});
		
		fileMenu.add(exitItem);
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.add(fileMenu);
		this.setJMenuBar(menuBar);
	}
    
    //public double[] userInput() {
        //double[] vars = new double[6];
        
       // try {
            //Prompts the user for the image's size (height == width)
          //  String imgSize = JOptionPane.showInputDialog("Please input the desired image size you would like");
          //  vars[0] = Double.parseDouble(imgSize);
            //Prompts the user for the number of stems
          //  String numStems = JOptionPane.showInputDialog("Please input the desired number of stems");
          //  vars[1] = Double.parseDouble(numStems);
            //Prompts the user for the number of steps per stem
         //   String numSteps = JOptionPane.showInputDialog("Please input the desired number of steps per stem");
         //   vars[2] = Double.parseDouble(numSteps);
            //Prompts the user for the transmission probability
         //   String transmission = JOptionPane.showInputDialog("Please input the desired transmission probability [0.0, 1.0]");
          //  vars[3] = Double.parseDouble(transmission);
            //Prompts the user for the maximum rotation increment
         //   String rotation = JOptionPane.showInputDialog("Please input the desired maximum rotation increment [0.0, 1.0]");
         //   vars[4] = Double.parseDouble(rotation);
            //Prompts the user for the growth segment increment
         //   String growthSeg = JOptionPane.showInputDialog("Please input the desired growth segment increment");
        //    vars[5] = Double.parseDouble(growthSeg);
            //Prompts the user for the desired hex colors
        //   firstColor = (String)JOptionPane.showInputDialog("Input a desired hex color for the base of the stems, Ex: 0x55101100");
         //   secondColor = (String)JOptionPane.showInputDialog("Input a desired hex color for the tips of the plant, Ex: 0xFF99FF00");

    
    // Methods utilized to gather prompts from the user
	
	private int promt_ImgSize() {
        //Prompts the user for the image's size (height == width)
		String result = JOptionPane.showInputDialog("Please input the desired image size you would like");
		int size = 1;
		try {
			size = Integer.parseInt(result);
		}
		catch(NumberFormatException n) {
			String tryAgain = JOptionPane.showInputDialog("Sorry, \"" + result + "\" is not a number. Please try again.");
			size = Integer.parseInt(tryAgain);
		}
		return size;
	}
	private int promt_Colors() {
        //Prompts the user for the desired hex colors
		String result = JOptionPane.showInputDialog("What colors would you like? Please input a desired hex color for the plant Ex: 0x55101100");
		int color = 1;
		try {
			color = (int)Long.parseLong(result.substring(2, result.length()), 16);
		}
		catch(NumberFormatException n) {
			String tryAgain = JOptionPane.showInputDialog("Sorry, \"" + result + "\" is not a number. Please try again.");
			color = (int)Long.parseLong(tryAgain.substring(2, tryAgain.length()), 16);
		}
		return color;		
	}
	private int promt_Stems() {
        //Prompts the user for the number of stems
		String result2 = JOptionPane.showInputDialog("Please input the desired number of stems");
		int Stems = 1;
		try {
			Stems =  Integer.parseInt(result2);
		}
		catch(NumberFormatException n) {
			String tryAgain = JOptionPane.showInputDialog("Sorry, \"" + result2 + "\" is not a number. Please try again.");
			Stems =  Integer.parseInt(tryAgain);
		}
		return Stems;		
	}
	private int promt_Steps() {
         //Prompts the user for the number of steps per stem
		String result3 = JOptionPane.showInputDialog("Please input the desired number of steps per stem");
		int Steps = 1;
		try {
			Steps =  Integer.parseInt(result3);
		}
		catch(NumberFormatException n) {
			String tryAgain = JOptionPane.showInputDialog("Sorry, \"" + result3 + "\" is not a number. Please try again.");
			Steps =  Integer.parseInt(tryAgain);
		}
		return Steps;		
	}
	private float promt_TransProb() {
        //Prompts the user for the transmission probability
		String result4 = JOptionPane.showInputDialog("Please input the desired transmission probability [0.0, 1.0]");
		float Prob = 1.0f;
		try {
			Prob =  Float.parseFloat(result4);
		}
		catch(NumberFormatException n) {
			String tryAgain = JOptionPane.showInputDialog("Sorry, \"" + result4 + "\" is not a number. Please try again.");
			Prob =  Integer.parseInt(tryAgain);
		}
		return Prob;		
	}
	private float promt_RotIncr() {
        //Prompts the user for the maximum rotation increment
		String result5 = JOptionPane.showInputDialog("Please input the desired maximum rotation increment [0.0, 1.0]");
		float Rot = 1;
		try {
			Rot =  Float.parseFloat(result5);
		}
		catch(NumberFormatException n) {
			String tryAgain = JOptionPane.showInputDialog("Sorry, \"" + result5 + "\" is not a number. Please try again.");
			Rot =  Integer.parseInt(tryAgain);
		}
		return Rot;		
	}
	private int promt_Growth() {
        //Prompts the user for the growth segment increment
		String result6 = JOptionPane.showInputDialog("Please input the desired growth segment increment");
		int Grow = 1;
		try {
			Grow =  Integer.parseInt(result6);
		}
		catch(NumberFormatException n) {
			String tryAgain = JOptionPane.showInputDialog("Sorry, \"" + result6 + "\" is not a number. Please try again.");
			Grow =  Integer.parseInt(tryAgain);
		}
		return Grow;		
	}
     // Runs the directed random walk plant algorithm discussed in class following the Random Walk plants handout

	private void draw(int totNumStems, int steps, float transProb, float thetaChange, int radChange, int colr1, int colr2) {
		//	this is a buffer img for the animation that will store the current growth state of the plant
		BufferedImage scrn = new BufferedImage(img.getWidth(), img.getHeight(), BufferedImage.TYPE_INT_ARGB);
		for(int y = 0; y < scrn.getHeight(); y++) {
			for(int x = 0; x < scrn.getWidth(); x++) {
				scrn.setRGB(x, y, img.getRGB(x, y));
			}
		}
		icon = new ImageIcon(scrn);
		label = new JLabel(icon);
		float tao = 0.0f;

		RenderingHints hint = new RenderingHints( RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		RenderingHints hint1 = new RenderingHints( RenderingHints.KEY_COLOR_RENDERING, RenderingHints.VALUE_COLOR_RENDER_QUALITY);
		
		// Implements the stroke and color
		setStrokesArray(steps);
		setColorsArray(colr1,colr2,steps);
		
		plant2D = (Graphics2D) img.createGraphics();
		Graphics2D scrn2D = (Graphics2D) scrn.createGraphics();
		plant2D.setRenderingHints(hint);
		scrn2D.setRenderingHints(hint);
		plant2D.setRenderingHints(hint1);
		scrn2D.setRenderingHints(hint1);

           // Sets the background color to black
		plant2D.setColor(Color.BLACK);
		plant2D.fillRect(0, 0, getWidth(), getHeight());
				
		//	Grows from the center point
		plant2D.setColor(pigment[0]);
		plant2D.setStroke(strokes[0]);

		//	array to hold all the stems
		stemObjs = new Stem[totNumStems];	

		//	determine initial stem
		for(int stem_i = 0; stem_i < totNumStems; stem_i++) {
			stemObjs[stem_i] = new Stem(transProb, radChange, thetaChange);
			plant2D.draw(stemObjs[stem_i].segment);
		}
        // Displays the new image to the screen
		scrn = img;
		displayBufferedImage(scrn);

        /** Method called by the user's selection in the JMenu file selection for the action Event. The program that will
         created a directed random walk plants simulation based on the directed random walk plant algorithm discussed in class.
         **/
        
		for(int f = 0; f < steps; f++) {
			//	clear curr scrn
			scrn2D.setColor(Color.BLACK);
			scrn2D.drawRect(0, 0, img.getWidth(), img.getHeight());
			
			//	determine curr state of plant growth
			for(int currStem = 0; currStem < totNumStems; currStem++) {
				//	determine bias
				tao = getTao(stemObjs[currStem].direction, currStem);
				//	flip coin, and set new direction
				stemObjs[currStem].direction = coinFlip(tao);
				//	determine where the nxt seg starts and ends
				stemObjs[currStem].computeOffsets();
				//	produce/draw segment of appropriate color and stroke width
				stemObjs[currStem].grow();
				plant2D.setColor(pigment[f]);
				plant2D.setStroke(strokes[f]);
				plant2D.draw(stemObjs[currStem].segment);
			}
			//	Displays the new image to the screen
			scrn = img;
			displayBufferedImage(scrn);
		}
	}

	// Method that determines tau, the virtual's coin bias
	private float getTao(int currDirection, int stemNumber) {
		if (currDirection == 1)		//	i.e., if the las turn was to the right 
			return stemObjs[stemNumber].alpha;
		else return stemObjs[stemNumber].beta;
	}
	
	// Calls the method that flips the biased coin, to determine which direction to turn next
	private int coinFlip(float bias) {
		if(rand.nextFloat() > bias) 
			return 1;
		else return -1;
		
	}
	
	 // Implements Color interpolation where the step per stem is for the plant
	private void setColorsArray(int c1, int c2, int steps) {
		//0xF1A347BC
		float r1 = (c1 >>> 16) & 0xFF, g1 = (c1 >>> 8) & 0xFF, b1 = c1 & 0xFF;
		float r2 = (c2 >>> 16) & 0xFF, g2 = (c2 >>> 8) & 0xFF, b2 = c2 & 0xFF;
		
		float dr = (r2 - r1) / steps;
		float dg = (g2 - g1) / steps;
		float db = (b2 - b1) / steps;
		
		pigment = new Color[steps];
		for(int s = 0; s < steps; s++) {
			r1 += dr;
			g1 += dg;
			b1 += db;
            // Implements the color channels
			pigment[s] = new Color((int)r1 << 16 | (int)g1 << 8 | (int)b1);
		}
		pigment[0] = new Color(c1);
		pigment[steps-1] = new Color(c2);
	}
	
	// Implements computing the stroke change as the plant grows
	private void setStrokesArray(int steps) {
		float start = 6.0f;
		float end = .5f;
		
		float ds = (start - end) / steps;
		
		strokes = new BasicStroke[steps];
		strokes[0] = new BasicStroke(start, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND);
		for(int s = 1; s < steps; s++) {
			strokes[s] = new BasicStroke(start -= ds); 
		}
	}
	 // The method to display our end buffered Image
	public void displayBufferedImage(BufferedImage image) {
		//	display BufferedImage
		//this.setContentPane(new JScrollPane(new JLabel(new ImageIcon(image))));
		//this.validate();
		icon.setImage(image);
		label.repaint();
		setContentPane(new JScrollPane(label));
		validate();
	}

	class Stem {
		float x = getWidth()/2, y = getHeight()/2;
		
		float r = 1.0f; 
		float dr;
		float theta = (float) ((Math.PI)/2);
		float dt;
		
		float alpha;			//	transmission probability
		float beta;				//	reflection probability
		int direction = -1;
	
		Line2D.Double segment;
		
		Stem(float al, float _dr, float _dt) {
			alpha = al;
			beta = 1 - al;
			
			dr = _dr;
			dt = _dt;
			
			//	initial segment
			segment = new Line2D.Double(x,y, x += r * Math.cos(theta), y += -r * Math.sin(theta));
		}
				
		public void computeOffsets() {
            // Method that computes an offset from end of the old growth segment to the end of the new one
			r += dr;
			theta += dt * rand.nextFloat() * direction;	
		}
		
		public void grow() {	
			segment.setLine(x, y, x += r * Math.cos(theta), y += -r * Math.sin(theta));	
		}		
	}
	
	
}