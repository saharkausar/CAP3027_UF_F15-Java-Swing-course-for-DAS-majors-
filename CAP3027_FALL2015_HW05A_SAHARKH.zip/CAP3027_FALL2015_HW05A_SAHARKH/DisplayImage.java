import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.io.*;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.*;
import javax.imageio.*;
import javax.swing.*;
import java.util.ArrayList;
import java.util.*;

public class DisplayImage
{
    
    private static final int WIDTH = 400;
    private static final int HEIGHT = 400;
    
    public static void main( String[] args)
    {
        JFrame frame = new ImageFrame(WIDTH, HEIGHT);
        frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
    
    
    private static class ImageFrame extends JFrame
    {
        // Constructor
        // Initialize the variables
        private static double x;
        private static double y;
        private static double beta;
        private static double alpha;
        private static int w;
        private static int h;
        private static int direction;
        private static double tau;
        private static double rhoDelta;
        private static double thetaDelta;
        private static double steps;
        private static double theta = (int)((Math.PI)/2);
        private static double rho = 1;
        
        ArrayList<Double> positionsX = new ArrayList<Double>();
        ArrayList<Double> positionsY = new ArrayList<Double>();
        ArrayList<Double> newTheta = new ArrayList<Double>();
        ArrayList<Double> rhoNew = new ArrayList<Double>();
        ArrayList<Integer> newDirection = new ArrayList<Integer>();
        private static final int black = 0xff000000;
        private static float currentStroke = 6;
        private static int newColorOne;
        private static int newColorTwo;
        private static String firstColor = "0x55101100";
        private static String secondColor = "0xFF99FF00";
        
        
        private final JFileChooser chooser;
        public static BufferedImage bufferedImage;
        
        // Sets up the frame's attributes and displays the menu
        
        public ImageFrame(int width, int height){
            
            //frame attributes
            this.setTitle("CAP 3027 2015 - HW05A - Sahar Hussain");
            this.setSize( width, height );
            
            //adds a menu to the frame
            addMenu();
            
            chooser = new JFileChooser();
            chooser.setCurrentDirectory(new File("."));
            //setup the file chooser dialog
        }
        private void addMenu(){
            
            // File Menu Option Display
            JMenu fileMenu = new JMenu("File");
            
            // Creates a JMenuItem for Directed Random Walk plant for the JMenu File if the user perform a random plant walk simulation
            
            JMenuItem openItem = new JMenuItem("Directed random walk plant");
            openItem.addActionListener( new ActionListener()
                                       {
                public void actionPerformed( ActionEvent event)
                {
                    plantWalk();
                }
            }   );
            fileMenu.add( openItem);
            
            // Creates a JMenuItem for the JMenu File if the user wishes to exit the program
            JMenuItem exitItem = new JMenuItem("Exit");
            exitItem.addActionListener( new ActionListener()
                                       {
                public void actionPerformed(ActionEvent event)
                {
                    System.exit( 0 );
                }
            }	);
            fileMenu.add( exitItem);
            
            JMenuBar menuBar = new JMenuBar();
            menuBar.add( fileMenu);
            this.setJMenuBar( menuBar);
        }
        
        // Methods utilized to gather prompts from the user
        
        public double[] userInput() {
            double[] vars = new double[6];
            
            try {
                //Prompts the user for the image's size (height == width)
                String imgSize = JOptionPane.showInputDialog("Please input the desired image size you would like");
                vars[0] = Double.parseDouble(imgSize);
                //Prompts the user for the number of stems
                String numStems = JOptionPane.showInputDialog("Please input the desired number of stems");
                vars[1] = Double.parseDouble(numStems);
                //Prompts the user for the number of steps per stem
                String numSteps = JOptionPane.showInputDialog("Please input the desired number of steps per stem");
                vars[2] = Double.parseDouble(numSteps);
                //Prompts the user for the transmission probability
                String transmission = JOptionPane.showInputDialog("Please input the desired transmission probability [0.0, 1.0]");
                vars[3] = Double.parseDouble(transmission);
                //Prompts the user for the maximum rotation increment
                String rotation = JOptionPane.showInputDialog("Please input the desired maximum rotation increment [0.0, 1.0]");
                vars[4] = Double.parseDouble(rotation);
                //Prompts the user for the growth segment increment
                String growthSeg = JOptionPane.showInputDialog("Please input the desired growth segment increment");
                vars[5] = Double.parseDouble(growthSeg);
                //Prompts the user for the desired hex colors
                firstColor = (String)JOptionPane.showInputDialog("Input a desired hex color for the base of the stems, Ex: 0x55101100");
                secondColor = (String)JOptionPane.showInputDialog("Input a desired hex color for the tips of the plant, Ex: 0xFF99FF00");
            }
            catch(NumberFormatException e) {
                //Prompts the user for the image's size (height == width)
                JOptionPane.showMessageDialog(this, "Error, please enter the correct input for the desired image size");
                String imgSize = JOptionPane.showInputDialog("Please enter the correct input for the desired image size");
                vars[0] = Double.parseDouble(imgSize);
                //Prompts the user for the number of stems
                JOptionPane.showMessageDialog(this, "Error, please enter the correct input for the desired number of stems");
                String numStems = JOptionPane.showInputDialog("Please enter the correct input for the desired number of stems");
                vars[1] = Double.parseDouble(numStems);
                //Prompts the user for the number of steps per stem
                JOptionPane.showMessageDialog(this, "Error, please enter the correct input for the desired number of steps per stem");
                String numSteps = JOptionPane.showInputDialog("Please enter the correct input for the desired number of steps per stem");
                vars[2] = Double.parseDouble(numSteps);
                //Prompts the user for the transmission probability
                JOptionPane.showMessageDialog(this, "Error, please input the desired transmission probability [0.0, 1.0]");
                String transmission = JOptionPane.showInputDialog("Please input the desired transmission probability [0.0, 1.0]");
                vars[3] = Double.parseDouble(transmission);
                //Prompts the user for the maximum rotation increment
                JOptionPane.showMessageDialog(this, "Error, please input the desired maximum rotation increment [0.0, 1.0]");
                String rotation = JOptionPane.showInputDialog("Please input the desired maximum rotation increment [0.0, 1.0]");
                vars[4] = Double.parseDouble(rotation);
                //Prompts the user for the growth segment increment
                JOptionPane.showMessageDialog(this, "Error, please input the desired growth segment increment");
                String growthSeg = JOptionPane.showInputDialog("Please input the desired growth segment increment");
                vars[5] = Double.parseDouble(growthSeg);
            }
            
            return vars;
        }
        
        /** Method called by the user's selection in the JMenu file selection for the action Event. The program that will
         created a directed random walk plants simulation based on the directed random walk plant algorithm discussed in class.
         **/
        
        public void plantWalk()
        {
            /** Calls the userInput() method where prompt[0] is the image size, prompt[1] is the number of stems, prompt[2] is the number of steps per stem, prompt[3] is the transmission probability from [0.0, 1.0], prompt[4] is the maxiumum rotation increment from [0.0 , 1.0], prompt[5] is the growth segment increment
             **/
            double[] prompt = userInput();
            
            rhoDelta = prompt[5]; // change in the growth segment length per step (in "pixels")
            thetaDelta = prompt[4]; // maximum change in rotation pet step (in radians)
            steps = prompt[2]; // stores the steps prompts in steps
            
            // Changes the hex input by stripping off the prefix
            // The default color of the plant is a bright green at the tips and dark brown at the base
            // The user may specify what desired colors they would like and this gets parsed
            newColorOne = (int)Long.parseLong( firstColor.substring( 2, firstColor.length() ), 16 );
            newColorTwo = (int)Long.parseLong( secondColor.substring( 2, secondColor.length() ), 16 );
            
            // Create a new BufferedImage
            bufferedImage = new BufferedImage((int)prompt[0], (int)prompt[0], bufferedImage.TYPE_INT_ARGB);
            Graphics2D g2d = (Graphics2D) bufferedImage.createGraphics();
            
            // Makes the anti-aliasing (smooth) render lines
            RenderingHints hint = new RenderingHints( RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2d.setRenderingHints( hint );
            
            // Sets the background color to black
            g2d.setColor(Color.BLACK);
            g2d.fill(new Rectangle(0,0,(int)prompt[0],(int)prompt[0]));
            
            // Runs the directed random walk plant algorithm discussed in class following the Random Walk plants handout
            w = (int) prompt[0];
            h = w;
            // grows from the point (x,y)
            x = w/2;
            y = h/2;
            
            // Creates the new reflection probability variables
            alpha = prompt[3];
            beta = rho - alpha; // reflection probability
            
            // Implements the Stroke
            currentStroke = newStroke(0);
            BasicStroke stroke = new BasicStroke( currentStroke, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND );
            g2d.setStroke( stroke );
            
            // Implements the color
            Color channel = new Color(colorInterpolate(0));
            g2d.setColor(channel);
    
            // Plots the initial segment for every stem
            g2d.drawLine((int)x,(int)(y), (int) x, (int)(y - rho));
            y = y - rho;
            double xPosition_New = x;
            double yPosition_New = y;
            positionsX.add(xPosition_New);
            positionsY.add(yPosition_New);
            newTheta.add(Math.PI/2);
            rhoNew.add(1.0);
            newDirection.add(1);
            
            // For every step
            for(int column = 1; column < steps; column++)
            {
                currentStroke = newStroke (column - 1);
                stroke = new BasicStroke( currentStroke, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND );
                g2d.setStroke( stroke );
                
                channel = new Color(colorInterpolate(column - 1));
                g2d.setColor(channel);
                
                // For every stem
                for(int row = 0; row < prompt[1]; row++)
                {
                    direction = 1;
                    
                    // If we have the initial position, we'll use the starting value
                    if (column ==1)
                    {
                        x = positionsX.get(0);
                        y = positionsY.get(0);
                        theta = newTheta.get(0);
                        rho = rhoNew.get(0);
                        direction = newDirection.get(0);
                    }
                    else
                        // we get the last position for the stem growth (i) = growth (row)
                    {
                        x = positionsX.get(row);
                        y = positionsY.get(row);
                        rho = rhoNew.get(row);
                        direction = newDirection.get(row);
                    }
                    
                    // Calls the method that determines tau, the virtual's coin bias
                    virtualCoin();
                    // Calls the method that flips the biased coin, to determine which direction to turn next
                    biasedCoin();
                    // Calls the method that computes an offset from end of the old growth segment to the end of the new one
                    offset();
                    // Implements converting to cartesian so we can draw a new line
                    xPosition_New = rho*Math.cos(theta) + x;
                    yPosition_New = y - rho*Math.sin(theta);
                    
                    // Draws a growth segment from the old position to the new position
                    g2d.drawLine((int)x,(int)y, (int)xPosition_New, (int) yPosition_New);
                    
                    // If we have the initial prompt, we add it to the array
                    
                    if (column == 1)
                    {
                        positionsX.add(xPosition_New);
                        positionsY.add(yPosition_New);
                        newTheta.add(theta);
                        rhoNew.add(rho);
                        newDirection.add(direction);
                    }
                    
                    else
                    {
                        positionsX.set(row, xPosition_New);
                        positionsY.set(row, yPosition_New);
                        newTheta.set(row, theta);
                        rhoNew.set(row, rho);
                        newDirection.set(row, direction);
                    }
                    
                }
            }
                // Displays the Image
                displayBufferedImage(bufferedImage);
        }
        
        // Method that computes an offset from end of the old growth segment to the end of the new one
        public void offset()
        {
            rho = ( rho + rhoDelta);
            theta = (theta + ( thetaDelta * Math.random() * direction));
        }
        
        // Calls the method that flips the biased coin, to determine which direction to turn next
        public void biasedCoin()
        {
            double random = Math.random();
            if(random > tau)
            {
                direction = 1;
            }
            else
            {
                direction = -1;
            }
        }
        
        // Method that determines tau, the virtual's coin bias
        public void virtualCoin()
        {
            if(direction == - 1)
            {
                tau = alpha;
            }
            else
            {
                tau = beta;
            }
        }
        
        // Implments the Stroke interpolation where the step per stem is for the plant
        
        public float newStroke(int numberOfSteps)
        {
            float valueS = (float) ((steps - numberOfSteps)*(6 - .5)/steps);
            
            return valueS;
        }
        
        // Implements Color interpolation where the step per stem is for the plant
        
        public int colorInterpolate(double stepNumber)
        {
            int alphaValue = (black >> 24) & 255;
            double redShift = Math.round((long)(stepNumber)*((getRed(newColorTwo) - getRed(newColorOne))/(steps)));
            double greenShift = Math.round((long)(stepNumber)*((getGreen(newColorTwo) - getGreen(newColorOne))/(steps)));
            double blueShift = Math.round((long)(stepNumber)*((getBlue(newColorTwo) - getBlue(newColorOne))/(steps)));
            
            int redValue = getRed(newColorOne);
            int greenValue = getGreen(newColorOne);
            int blueValue = getBlue(newColorOne);
            
            int value = (alphaValue << 24)|((redValue + (int)redShift) << 16)|((greenValue + (int)greenShift) << 8)|(blueValue + (int)blueShift);
            return value;
        }
        
        // Implements the color channels
        public int getRed(int channel)
        {
            return (channel >> 16) & 255;
        }
        public int getGreen(int channel)
        {
            return (channel >> 8) & 255;
        }
        public int getBlue(int channel)
        {
            return (channel) & 255;
        }
        
        // The method to display our end buffered Image
        
        public void displayBufferedImage( BufferedImage image)
        {
            this.setContentPane( new JScrollPane(new JLabel(new ImageIcon(image))));
            newTheta.clear();
            positionsX.clear();
            positionsY.clear();
            rhoNew.clear();
            newDirection.clear();
            this.validate();
        }
    }
}