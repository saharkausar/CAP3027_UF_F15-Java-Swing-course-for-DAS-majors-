//DisplayImage.java
//Allows a user to select and display images
//illustrates how to create a JFrame with a menubar,
//define ActionListeners,
//use a JFileChooser,
//open and display an image inside a JScrollPane

//by Dave Small
//HW11 Modification to original HW00 code and work by Sahar KH

/**For this assignment, I shall be implementing one of the Cellular Automata Techniques
 as described in Lecture: Cellular Automata and demonstrating Conway's Game of Life
 **/

// Import the libraries

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.List;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.Line2D;
import java.awt.geom.*;
import java.awt.geom.Point2D;
import java.awt.*;
import java.lang.Math;
import java.lang.Character;
import java.util.Stack;
import java.util.Scanner;
import java.awt.event.*;
import java.awt.image.*;
import java.io.*;
import javax.imageio.*;
import java.awt.Graphics;
import java.lang.Math.*;
import java.lang.Math;
import javax.swing.*;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import java.util.ArrayList;
import java.io.IOException;
import java.io.FileReader;
import java.io.BufferedReader;
import java.util.Random;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.*;
import java.lang.Object;
import java.awt.Robot;


class DisplayImage
{
     // Has a fractal display panel 800 pixels wide and 800 pixels tall
    
    private static final int WIDTH = 800;
    
    private static final int HEIGHT = 800;
    
    public static void main(String[] args)
    {
        SwingUtilities.invokeLater(new Runnable()
                                   {
            public void run()
            {
                createAndShowGUI();
            }
        });
    }
    private static void createAndShowGUI()
    {
        JFrame frame = new ImageFrame(WIDTH, HEIGHT);
        
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        frame.setVisible(true);
    }
}

class ImageFrame extends JFrame {
    // Constructor
    // Initialize the variables
    
    private final JFileChooser chooser;
    
    private static final int DELAY = 500;
    
    // Creates the fractal display panel with 800 pixels wide and 800 pixels tall
    
    BufferedImage image = new BufferedImage(800,800, BufferedImage.TYPE_INT_ARGB);
    
    BufferedImage buffer;
    
    Graphics2D g2d = (Graphics2D) image.createGraphics();
    
    Graphics2D bufferg2d;
    
    ImageIcon icon = new ImageIcon(this.image);
    
    JLabel label = new JLabel(icon);
    
    final JButton stateButton = new JButton( "Start" );
    
    Timer timer;
    
    Boolean gameRunning = false, initialized = false;
    
    //In both cases the grid shall consist of 100x100 cells (thus each cell is 8 pixels tall and wide).
    
    char[][] grid = new char[100][100];
    
    Random random = new Random();
    
    int row = 0;
    int column = 0;
    int neighbors = 0;
    
    double valueInput = 0.0;
    
    char currentPixel;
    
    String line = "";
    
    // Color scheme for our particles
    
    Color dead = Color.RED;		// dead cell (died this generation; a cell cannot be red for two successive generations == 'd'
    
    Color gone = Color.BLACK;	// dead cell (initially dead or dead for more than 1 generation) == 'g'
    
    Color alive = Color.GREEN;	// live cell (born this generation; a cell cannot be green for two successive generations) == 'a'
    
    Color old = Color.BLUE;		// live cell (live for more than 1 generation) =='o'
    
    public ImageFrame (int width, int height) {
        
        //The title-bar describes the assignment (CAP 3027 2015 - HWxx - your name)
        
        this.setTitle("CAP 3027 2015 - HW11 - Sahar Hussain");
        
        this.setSize(width, height);
        
        addMenu();
        
        chooser = new JFileChooser();
        
        chooser.setCurrentDirectory(new File("."));
    }
    
    //The File menu has the following selections
    //Randomly populated world
    //Empty world
    //Save image
    //Exit
    
    //---------------------------------- Methods that implement the menu functions------------------------------------------//

    
    private void addMenu () {
        
        ActionListener play = new ActionListener() {
            
            public void actionPerformed(ActionEvent event) {
                
                play();
            }
        };
        
        this.timer = new Timer(DELAY, play);
        
        stateButton.addActionListener( new ActionListener() {
            
            public void actionPerformed( ActionEvent event ) {
                
                if (gameRunning)
                    
                    endGame();
                
                else {
                    
                    stateButton.setText("Pause");
                    
                    gameRunning = true;
                    
                    timer.start();
                }
            }
        } );
        
        this.label.addMouseListener( new MouseAdapter() {
            
            public void mouseReleased(MouseEvent event) {
                
                if ((event.getModifiers() == MouseEvent.BUTTON1_MASK) && (gameRunning == false) && (initialized == true))
                    
                    switchColor(event.getPoint());
            }
        } );
        
        // Includes a JMenu FileMenu that includes the Randomly Populated World, Empty World, Save Image, and exit options.
        // Also includes the Options for loading a configuration file and saving the configuration file
        
        JMenu fileMenu = new JMenu("File");
        
        // Adds a JMenu ItemMenu that Randomly Populates the World
        JMenuItem populateTheWorld = new JMenuItem("Randomly Populated World");
        
        populateTheWorld.addActionListener (new ActionListener () {
            
            public void actionPerformed (ActionEvent event) {
                
                endGame();
                
                beginGame(userInputProbability());
            }
        });
        
        fileMenu.add(populateTheWorld);
        
        // Adds a JMenu ItemMenu that empties the world
        JMenuItem emptyTheWorld = new JMenuItem("Empty World");
        
        emptyTheWorld.addActionListener (new ActionListener () {
            
            public void actionPerformed (ActionEvent event) {
                
                endGame();
                
                beginGame(0.0);
            }
        });
        
        fileMenu.add(emptyTheWorld);
        
        // Adds a JMenu ItemMenu that saves the image
        JMenuItem saveTheImage = new JMenuItem("Save image");
        
        saveTheImage.addActionListener (new ActionListener () {
            
            public void actionPerformed (ActionEvent event) {
                
                endGame();
                
                saveImage();
            }
        });
        
        fileMenu.add(saveTheImage);
        
        // Adds a JMenu ItemMenu that loads the configuration file
        JMenuItem loadTheConfig = new JMenuItem("Load the configuration file");
        
        loadTheConfig.addActionListener (new ActionListener () {
            
            public void actionPerformed (ActionEvent event) {
                
                endGame();
                
                loadConfiguration(); // User chooses a configuration file with the file populated with 100 rows and 100 cols of random chars consisting of 'a', 'g', 'o', 'd'
            }
        });
        
        fileMenu.add(loadTheConfig);
        
        // Adds a JMenu ItemMenu that saves the configuration file
        JMenuItem saveTheConfig = new JMenuItem("Save the configuration file");
        
        saveTheConfig.addActionListener (new ActionListener () {
            
            public void actionPerformed (ActionEvent event) {
                
                endGame();
                
                saveConfiguration(); // User chooses a new text file they have saved in the repository, the new configuration file will be written to it
            }
        });
        
        fileMenu.add(saveTheConfig);
        
        JMenuItem exitItem = new JMenuItem("Exit");
        
        exitItem.addActionListener( new ActionListener () {
            
            public void actionPerformed (ActionEvent event) {
                
                endGame();
                
                System.exit(0);
            }
        });
        
        fileMenu.add(exitItem);
        
        JMenuBar menuBar = new JMenuBar();
        
        menuBar.add(fileMenu);
        
        this.setJMenuBar(menuBar);
        
        SwingUtilities.invokeLater(new Runnable () {
            
            public void run() {
                
                /**
                 
                 Has a button at the bottom of the frame which allows the user to toggle between running and pausing the simulation. The system will begin in the paused state and the button will read "Start." When the system is in the running state the button will read "Pause." When the button is clicked the system's state (and button text) will change.
                 
                 **/
                
                getContentPane().add(new JScrollPane(label));
                
                getContentPane().add(stateButton, BorderLayout.SOUTH);
                
                validate();
            }
        });
    }
    
    //-----------------------------------------------------------------------------------------------------------------------------//
    
    //---------------------------------- Methods that implements getting the user's input------------------------------------------//

    
    private double userInputProbability ()
    {
        
        Boolean inputChecker = true;
        
        double range = -1;
        
        String inputProb = JOptionPane.showInputDialog("Please enter the desired probability of a random cell being alive, Ex. [0.0, 1.0]");
        
        while (inputChecker)
        {
            
            try
            {
                
                range = Double.parseDouble(inputProb);
                
                if ((range < 0.0) || (range > 1.0)) // If input is out of the range we specified for the user
                    
                    throw new IllegalArgumentException(); // We throw an exception
                
                inputChecker = false;
            }
            
            catch (NumberFormatException e) // Catches the format except and asks to input again
            {
                
                inputProb = JOptionPane.showInputDialog("Input Invalid. Please enter the desired probability of a random cell being alive, Ex. [0.0, 1.0]");
            }
            
            catch (IllegalArgumentException e)
            {
                inputProb = JOptionPane.showInputDialog("Input Invalid. Please enter the desired probability of a random cell being alive, Ex. [0.0, 1.0]");
                
            }
            
        }
        
        return range; // Returns the probability they inputted for use for later
    }

      //----------------------------------------------------------------------------------------------------------------------------//
    
     //---------------------------------- Methods that implements Conway Game of Life System------------------------------------------//
    
    public void switchColor (Point point)
    {
        row = point.x/8;
        column = point.y/8;
        
        if ((this.grid[row][column] == 'g') || (this.grid[row][column] == 'd'))
        {
            this.grid[row][column] = 'a';
            
            this.g2d.setColor(this.alive);
            
            this.g2d.fillRect(8 * row, 8 * column, 8, 8);
        }
        
        else
        {
            this.grid[row][column] = 'd';
            
            this.g2d.setColor(this.dead);
            
            this.g2d.fillRect(8 * row, 8 * column, 8, 8);
            
        }
        
        displayBufferedImage(this.image);
    }
    
    public void beginGame (double probRange)
    {
        for (row = 0; row < 100; ++row)
        {
            for (column = 0; column < 100; ++column)
            {
                
                valueInput = this.random.nextDouble();
                
                if (valueInput <= probRange) {
                    
                    grid[row][column] = 'a';
                    
                    
                    g2d.setColor(this.alive);
                }
                
                else
                    
                {
                    grid[row][column] = 'd';
                    
                    g2d.setColor(this.dead);
                    
                }
                
                this.g2d.fillRect(8 * row, 8 * column, 8, 8);
                
            }
            
        }
        
        this.initialized = true;
        
        displayBufferedImage(this.image);
    }
    
    public void play () {
        
        buffer = new BufferedImage(800,800, BufferedImage.TYPE_INT_ARGB);
        
        bufferg2d = (Graphics2D) buffer.createGraphics();
        
        // for every row
        
        for (row = 0; row < 100; ++row)
            
        {
            // for every column
            
            for (column = 0; column  < 100; ++column )
                
            {
                currentPixel = this.grid[row][column];
                
                this.neighbors = getNeighbors(row,column);
                
                if ((currentPixel == 'g') || (currentPixel == 'd'))
                    
                {
                    if (this.neighbors == 3)
                    {
                        
                        this.grid[row][column] = 'a';
                        
                        bufferg2d.setColor(this.alive);
                        
                    }
                    
                    else
                    {
                        
                        if (currentPixel == 'd')
                            
                            this.grid[row][column] = 'g';
                        
                        bufferg2d.setColor(this.gone);
                    }
                }
                
                else
                {
                    
                    if ((this.neighbors < 2) || (this.neighbors > 3))
                    {
                        
                        this.grid[row][column] = 'd';
                        
                        bufferg2d.setColor(this.dead);
                        
                    }
                    
                    else
                    {
                        
                        if (currentPixel == 'a')
                            
                            this.grid[row][column] = 'o';
                        
                        bufferg2d.setColor(this.old);
                    }
                }
                
                bufferg2d.fillRect(row * 8, column * 8, 8, 8);
            }
            
        }
        
        this.image = buffer;
        
        this.g2d = bufferg2d;
        
        displayBufferedImage(buffer);
        
    }
    
    public void endGame ()
    {
        
        this.timer.stop();
        
        this.stateButton.setText("Start");
        
        this.gameRunning = false;
    }
    
    public int getNeighbors (int x, int y)
    
     // The world is assumed to be toroidal
     // Checks the bounds of each neighboring pixel in the toroidal world
    
    {
        int neighLive = 0;
        
        int Xdecrease, Ydecrease, Xincrease, Yincrease;
        
        Xdecrease = (x == 0) ? 99 : x - 1;
        
        Ydecrease = (y == 0) ? 99 : y - 1;
        
        Xincrease = (x == 99) ? 0 : x + 1;
        
        Yincrease = (y == 99) ? 0 : y + 1;
        
        if ((this.grid[Xdecrease][Ydecrease] == 'o') || (this.grid[Xdecrease][Ydecrease] == 'a'))
            
            ++neighLive;
        
        if ((this.grid[x][Ydecrease] == 'o') || (this.grid[x][Ydecrease] == 'a'))
            
            ++neighLive;
        
        if ((this.grid[Xincrease][Ydecrease] == 'o') || (this.grid[Xincrease][Ydecrease] == 'a'))
            
            ++neighLive;
        
        if ((this.grid[Xincrease][y] == 'o') || (this.grid[Xincrease][y] == 'a'))
            
            ++neighLive;
        
        if ((this.grid[Xincrease][Yincrease] == 'o') || (this.grid[Xincrease][Yincrease] == 'a'))
            
            ++neighLive;
        
        if ((this.grid[x][Yincrease] == 'o') || (this.grid[x][Yincrease] == 'a'))
            
            ++neighLive;
        
        if ((this.grid[Xdecrease][Yincrease] == 'o') || (this.grid[Xdecrease][Yincrease] == 'a'))
            
            ++neighLive;
        
        if ((this.grid[Xdecrease][y] == 'o') || (this.grid[Xdecrease][y] == 'a'))
            
            ++neighLive;
        
        return neighLive;
    }
    
      //----------------------------------------------------------------------------------------------------------------------------//
    
    
    private void saveImage()
    {
        // Prompts the user to enter a desired file name
        
        String savingFileName = (String)JOptionPane.showInputDialog("Enter the desired name for the PNG file you'd like to save");
        
        // Saves the file as a png (portable network graphics)
        savingFileName += ".png";
        
        File outputFile = new File(savingFileName);
        try
        {
            javax.imageio.ImageIO.write( image, "png", outputFile );
        }
        catch ( IOException e )
        {
            JOptionPane.showMessageDialog( ImageFrame.this,
                                          "Error saving file",
                                          "oops!",
                                          JOptionPane.ERROR_MESSAGE );
        }
    }
    
    //--------------- Methods that implement allowing the user to load and save configuration files—i.e., textual descriptions of the system.-----------//
    
    
    // User chooses a configuration file with the file populated with 100 rows and 100 cols of random chars consisting of 'a', 'g', 'o', 'd'
    
    public void loadConfiguration()
    {
        gridConfig();
        
        // For every row
        for (row = 0; row < 100; ++row)
        {
            // For every column
            for (column = 0; column < 100; ++column)
                
            {
                if (grid[row][column] == 'a')
                    
                    g2d.setColor(this.alive);
                
                else if (grid[row][column] == 'd')
                    
                    g2d.setColor(this.dead);
                
                else if (grid[row][column] == 'o')
                    
                    g2d.setColor(this.old);
                
                else
                    
                    g2d.setColor(this.gone);
                
                this.g2d.fillRect(8 * row, 8 * column, 8, 8);
                
            }
        }
        
        this.initialized = true;
        
        // Displays our new buffered image
        displayBufferedImage(this.image);
    }
    
    public void gridConfig()
    {
        Boolean inputChecker = true;
        
        File file = null;
        
        FileInputStream inputFile = null;
        
        BufferedInputStream bufferedFile = null;
        
        DataInputStream dis = null;
        
        while (inputChecker)
        {
            if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION)
                
                file = chooser.getSelectedFile();
            
            try
            {
                inputFile = new FileInputStream(file);
                
                bufferedFile = new BufferedInputStream(inputFile);
                
                BufferedReader br = new BufferedReader(new InputStreamReader(bufferedFile));
                
                for (row = 0; row != 100; ++row)
                    
                {
                    this.line = br.readLine();
                    
                    for (column = 0; column != 100; ++column)
                        
                        this.grid[row][column] = line.charAt(column);
                }
                
                inputFile.close();
                
                bufferedFile.close();
                
                br.close();
                
                inputChecker = false;
            }
            catch (FileNotFoundException exception)
            {
                JOptionPane.showMessageDialog(this, exception);
                
            } catch (IOException exception)
            {
                
                JOptionPane.showMessageDialog(this, exception);
            }
        }
    }
    
    public void saveConfiguration () // User chooses a new text file they have saved in the repository, the new configuration file will be written to it
    {
        File file = null;
        
        if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION)
            
            file = chooser.getSelectedFile();
        
        if (file != null)
        {
            try {
                BufferedWriter output = new BufferedWriter(new FileWriter(file));
                
                for (row = 0; row != 100; ++row)
                {
                    
                    this.line = "";
                    
                    for (column = 0; column != 100; ++column)
                    {
                        
                        this.line += this.grid[row][column];
                        
                    }
                    
                    output.write(line + "\n");
                    
                }
                
                output.close();
                
            } catch ( IOException e )
            {
                
                e.printStackTrace();
                
            }
            
        }
        
    }
    
    //---------------------------------------------------------------------------------------------------------------------------------------------//

    
    // Displays our new Buffered Image
    public void displayBufferedImage (final BufferedImage image)
    {
        
        SwingUtilities.invokeLater(new Runnable ()
                                   {
            
            public void run()
            {
                // Set the image
                icon.setImage( image );
                
                // Repaints the image label
                label.repaint();
                
                validate();
                
            }
            
        });
        
    }
}