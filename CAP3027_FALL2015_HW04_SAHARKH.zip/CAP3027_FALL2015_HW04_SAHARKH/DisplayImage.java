import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.io.*;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.*;
import javax.imageio.*;
import javax.swing.*;

public class DisplayImage
{
    
    private static final int WIDTH = 400;
    private static final int HEIGHT = 400;
    
    public static void main( String[] args)
    {
        JFrame frame = new ImageFrame(WIDTH, HEIGHT);
        frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }


    public static class ImageFrame extends JFrame
    {
    
        private final JFileChooser chooser;
        private BufferedImage image = null;
    
        //Constructors
        private int width, height, totalGrid, minCircle;
        
        //int maxArea = gridDimension * gridDimension
        
        // Sets up the frame's attributes and displays the menu
    
        public ImageFrame(int width, int height){
    
        //frame attributes
        this.setTitle("CAP 3027 2015 - HW04 - Sahar Hussain");
        this.setSize( width, height );
        
        //adds a menu to the frame
        addMenu();
        
        chooser = new JFileChooser();
        chooser.setCurrentDirectory(new File("."));
        //setup the file chooser dialog
    }
        private void addMenu(){
        
            // File Menu Option Display
            JMenu fileMenu = new JMenu("File");
        
            // Creates a JMenuItem loadImage for the JMenu File if the user wishes to load their source image to create the design

        
            JMenuItem openItem = new JMenuItem("Load source image");
            openItem.addActionListener( new ActionListener()
            {
            public void actionPerformed( ActionEvent event)
                {
                loadImage();
                }
            }   );
            fileMenu.add( openItem);
        
            // Creates a JMenuItem for the JMenu File if the user wishes to exit the program
            JMenuItem exitItem = new JMenuItem("Exit");
            exitItem.addActionListener( new ActionListener()
                                       {
                public void actionPerformed(ActionEvent event)
                {
                    System.exit( 0 );
                }
            }	);
            fileMenu.add( exitItem);
        
            JMenuBar menuBar = new JMenuBar();
            menuBar.add( fileMenu);
            this.setJMenuBar( menuBar);
        }

        // Method utilized to prompt the user for the minimum circle diameter
    
        private int userInput(){
            int i = 0;
            try {
                String prompt = JOptionPane.showInputDialog("Please input a minimum circle diameter");
                i = Integer.parseInt(prompt);
            }
            catch(NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Error, please input a minimum circle diameter");
                String prompt = JOptionPane.showInputDialog("Please enter a minimum circle diameter");
                i = Integer.parseInt(prompt);
            }
            return i;
        }
        
        // Method that gets the width and height of the source image. And then returns the minimum value of the width or height. If the width is less than the height or the height is less than the width of the source image, we will return this value.
        
        private int getDimensions(int sourceWidth, int sourceHeight){
            int minDimension;
            
            // Returns the minimum value of the width or height. If the width is less than the height or the height is less than the width of the source image, we will return this value.
            
            if(sourceWidth<=sourceHeight)
            {
                minDimension = sourceWidth;
            }
            else
            {
                minDimension = sourceHeight;
            }
            
            return minDimension;
        }
        
        // Calls the square buffered image and sets the background color to black
        private void blackBackground(int grid, BufferedImage squareImage)
        {
            for(int row = 0; row < grid; row++)
            {
                for(int column =0; column < grid; column++)
                {
                    squareImage.setRGB(row,column,0xFF000000);
                }
            }
        }
    
        private void loadImage()
        {
            //open a file selected by the user
            File sourceImage = getFile();
            if(sourceImage != null)
            {
                BufferedImage obtainImage = obtainSourceImage(sourceImage);
                width = obtainImage.getWidth();
                height = obtainImage.getHeight();
            
                // Returns the minimum value of the width or height. If the width is less than the height or the height is less than the width of the source image, we will return this value.
                totalGrid = getDimensions(width,height);
            
                // Creates the new square buffered image and sets it to black
                BufferedImage obtainImage_New = new BufferedImage(totalGrid,totalGrid,BufferedImage.TYPE_INT_RGB);
                Graphics2D target = (Graphics2D)obtainImage_New.createGraphics();
                target.setBackground(Color.BLACK);
                int row = 0, column = 0;
            
                minCircle = userInput();
                if(minCircle>totalGrid)
                {
                    minCircle = totalGrid-1;
                }
            
            //Calculates the average color pixel
            //averageColor(sourceImage, 0,0,minDimension,minDimension);
            
            //Draws a solid circle of the average color that fills the target
            //drawCircle(BufferedImage, x, y, height, width, color)
            
            /**Recursively (until circle radius <= user specified minimum)
             for top-left quadrant ( for int x = xMin, x <= xWidth/2, x++)
             (for int y = yMin, y <= yHeight/2, y++)
             
             color = averageColor(..)
             drawCircle (image, x, y, height/2, width/2, color)
             if (height/2 > minCircle)
             fillSquare(x,y, height/2, width/2)
             
             
             for top-right quadrant   (for int x = xWidth/2, x <= xMax, x++)
             (for int y = yMin, yMin <= yHeight/2, y++)
             
             for bottom-left quadrant  (for int x = xMin, x <= xWidth/2, x++)
             (for int y = yHeight/2, y <= yMax, y++)
             
             for bottom-right quadrant  (for int x = xWidth/2, x <= xMax, x++)
             (for int y = yHeight/2, y <= yMax, y++)
             
             
             **/
            
            circleRecursion(obtainImage,target,minCircle,totalGrid,row,column);
            
            // Displays the new file that we emit after recursion
            
            displayFile( obtainImage_New );
            }
        }
    
        // Method that calculates the average pixel color of our source image where xMin and yMin is the upper left coordinate and xMax and yMax is the width and the height of the source image
    
        private long [] AverageColor(BufferedImage sourceImageBuffered,int gridDimension,int xMin, int yMin)
        {
            long red = 0, green = 0, blue = 0;
            
            long getAverageColor[] = new long [4];
            
            /**
             
             int xWidth = xMin + xMax;    (Where we know that the width of the image is equal to the minumum x value on the left coordinate and is equal to the max x coordinate on the right coordinate of the grid).
             int yHeight = yMin + yMax;    (Where we know the that height of the image is equal to the minimum y value on the left coordinate and is equal to the max y coordinate on the bottom coordinate of the grid).
             long red = 0, green = 0, blue = 0;
             
             // for each row
             for (int x = xMin; x < xWidth; x++){
             // for each column
             for (int y = yMin; y < yHeight; y++){
             // extracts the total red, green, blue (RGB) channels from the source image
             Color pixel = new Color(sourceImage.getRGB(x,y));
             red += pixel.getRed();
             green += pixel.getGreen();
             blue += pixel.getBlue();
             
             
             **/
        
            // for each row
            for(int row = xMin; row < (xMin + gridDimension -1); row++)
            {
                //for each column
                for(int column = yMin; column < (yMin + gridDimension-1); column++)
                {
                    // extracts the total red, green, blue (RGB) channels from the buffered source image
                    red +=  extractRed(sourceImageBuffered,row,column);
                    green += extractGreen(sourceImageBuffered,row,column);
                    blue += extractBlue(sourceImageBuffered,row,column);
                }
            }
        
            //Calculates the average color pixel
            //averageColor(sourceImage, 0,0,minDimension,minDimension);
            
            int maxArea = gridDimension * gridDimension;
            
            getAverageColor[1] = red / (maxArea);
            getAverageColor[2] = green / (maxArea);
            getAverageColor[3] = blue / (maxArea);
        
            // returns the average pixel color of the source image
            return getAverageColor;
        
        }
        
        
        /**Recursively (until circle radius <= user specified minimum)
         for top-left quadrant ( for int x = xMin, x <= xWidth/2, x++)
         (for int y = yMin, y <= yHeight/2, y++)
         
         color = averageColor(..)
         drawCircle (image, x, y, height/2, width/2, color)
         if (height/2 > minCircle)
         fillSquare(x,y, height/2, width/2)
         
         **/
        
        private void circleRecursion(BufferedImage targetBuffer, Graphics2D newTarget,int minCircleInput,int grid,int xMin,int yMin)
        {
            // Draws solid circles as the image fills the target
            while(!(grid<=minCircleInput))
            {
                long [] newCircleColor = AverageColor(targetBuffer,grid,xMin,yMin);
                Color colorCircle = new Color((int)newCircleColor[1],(int)newCircleColor[2],(int)newCircleColor[3]);
                newTarget.setColor(colorCircle);
                Ellipse2D circleRecursion = new Ellipse2D.Float(xMin,yMin,grid,grid);
                newTarget.fill(circleRecursion);
                
                
                /**
                 for top-right quadrant   (for int x = xWidth/2, x <= xMax, x++)
                 (for int y = yMin, yMin <= yHeight/2, y++)
                 
                 for bottom-left quadrant  (for int x = xMin, x <= xWidth/2, x++)
                 (for int y = yHeight/2, y <= yMax, y++)
                 
                 for bottom-right quadrant  (for int x = xWidth/2, x <= xMax, x++)
                 (for int y = yHeight/2, y <= yMax, y++)
                 
                 
                 **/
                
                // creates new target buffers at specified locations
                grid = grid/2;
                circleRecursion(targetBuffer, newTarget, minCircleInput, grid, xMin, yMin);
                // for top-left quadrant ( for int x = xMin, x <= xWidth/2, x++)
                circleRecursion(targetBuffer, newTarget, minCircleInput, grid, xMin+grid, yMin);
                // for top-right quadrant   (for int x = xWidth/2, x <= xMax, x++)
                circleRecursion(targetBuffer, newTarget, minCircleInput, grid, xMin, yMin+grid);
                // for bottom-left quadrant  (for int x = xMin, x <= xWidth/2, x++)
                circleRecursion(targetBuffer, newTarget, minCircleInput, grid, xMin+grid, yMin+grid);
                // for bottom-right quadrant  (for int x = xWidth/2, x <= xMax, x++)
            }
        }
        
        
        private File getFile(){
            File sourceImage = null;
            if(chooser.showOpenDialog(this) ==JFileChooser.APPROVE_OPTION)
            {
                sourceImage = chooser.getSelectedFile();
            }
            return sourceImage;
        }
        private BufferedImage obtainSourceImage(File sourceImage)
        {
        
            try{
                BufferedImage sourceImageBuffered = ImageIO.read(sourceImage);
                return sourceImageBuffered;
            }
            catch(IOException exception){
                JOptionPane.showMessageDialog( this, exception);
            }
            return null;
        }
    
        //display specified file in the frame
        private void displayFile(BufferedImage squareImage)
        {
            try
            {
            displayBufferedImage(squareImage);
            }
            catch(Exception exception)
            {
            JOptionPane.showMessageDialog( this, exception);
            }
        }
        
        // Returns the RGB color channels for the square image that will be called
        
        private int extractRed(BufferedImage squareImage,int row, int column)
        {
            return squareImage.getRGB(row,column)<<8>>> 24;
        }
        private int extractGreen(BufferedImage squareImage,int row, int column)
        {
            return squareImage.getRGB(row,column)<<16>>> 24;
            
        }
        private int extractBlue(BufferedImage squareImage,int row,int column)
        {
            return squareImage.getRGB(row,column)<<24>>> 24;
            
        }
    
        // The method to display our end buffered Image
    
        public void displayBufferedImage( BufferedImage image)
        {
            this.setContentPane( new JScrollPane(new JLabel(new ImageIcon(image))));
            this.validate();
        }
    }
}