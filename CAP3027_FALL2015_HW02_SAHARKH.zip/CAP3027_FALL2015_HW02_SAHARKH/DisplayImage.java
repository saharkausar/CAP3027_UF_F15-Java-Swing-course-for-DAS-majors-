import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.io.*;
import java.util.Scanner;
import java.util.Random;
import javax.imageio.*;
import javax.swing.*;


public class DisplayImage
{
    private static final int WIDTH  = 401;
    private static final int HEIGHT = 401;
    
    public static void main( String[] args )
    {
        JFrame frame = new ImageFrame( WIDTH, HEIGHT );
        frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
        frame.setVisible( true );
    }
    
    public static class ImageFrame extends JFrame
    {
        // Sets up the frame's attributes and displays the menu
        public ImageFrame(int width, int height)
        {
            this.setTitle("CAP3027 2015 - HW02 - Sahar Hussain");
            this.setSize( width, height );
            
            addMenu();
        }
        
        public void addMenu()
        {
            // File Menu Option Display
            JMenu fileMenu = new JMenu ("File");
            
            // Creates a JMenuItem bilinearGradient for the JMenu File if the user wishes to perform Bilinear Interpolation
            JMenuItem bilinearGradient = new JMenuItem("Bilinear Gradient");
            bilinearGradient.addActionListener(new ActionListener()
                                               {
                public void actionPerformed(ActionEvent event)
                {
                    bilInter();
                }
            }   );
            
            fileMenu.add(bilinearGradient);
                
            
            // Creates a JMenuItem for the JMenu File if the user wishes to exit the program
            JMenuItem exitItem = new JMenuItem("Exit");
            exitItem.addActionListener(new ActionListener()
                                       {
                public void actionPerformed(ActionEvent event)
                {
                    System.exit(0);
                }
            }   );
            
            fileMenu.add(exitItem);
            
            JMenuBar menuBar = new JMenuBar();
            menuBar.add(fileMenu);
            this.setJMenuBar(menuBar);
        }
        
        // The method utilized allowing the user to input the desired image size that they wish to conduct bilinear interpolation and produce in the Buffered image
        
        private int userInput() {
            int i = 0;
            try {
                String prompt = JOptionPane.showInputDialog("Please input the desired image size you would like");
                i = Integer.parseInt(prompt);
            }
            catch(NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Error, please input the desired image size you would like");
                String prompt = JOptionPane.showInputDialog("Please enter the desired image size");
                i = Integer.parseInt(prompt);
            }
            return i;
        }
        
        /**The method utilized for producing and/or generating two colors in which we will extract, combine and then synthesize for our extrapolation and interpolations and our iterative algorithm is used to sequentially generate (n+1) evenly spaced steps. This will get called by our 'biInter' method to perform bilinear interpolation. The algorithm includes have the color channels calculated per channel, and per each row for each pixel where each color 'Red', 'Blue', and 'Green', has its own first pixel and second pixel (or last) entry. 
         
         **/
        
        private int combo(int first, int second, int change, int step) {
            // Extract
            int firstRed = (first >> 16) & 0xff;
            int firstGreen = (first >> 8) & 0xff;
            int firstBlue = first & 0xff;
            int secondRed = (second >> 16) & 0xff;
            int secondGreen = (second >> 8) & 0xff;
            int secondBlue = second & 0xff;
            
            // Combine
            int comboRed = (int)(firstRed + change*(secondRed-firstRed)/(float)step);
            int comboGreen = (int)(firstGreen + change*(secondGreen - firstGreen)/(float)step);
            int comboBlue = (int)(firstBlue + change*(secondBlue - firstBlue)/(float)step);
            
            // Synthesize
            return (0xff000000 | ((comboRed << 16) & 0xff0000) | ((comboGreen << 8) & 0xff00) | (comboBlue & 0xff));
        }
        
        
        /** Bilinear Interpolation method for the JMenuItem bilinearGradient in which we will call our 'combo' method for synthesis. This calls the 'combo' method to perform interpolations vertically in the nested for loop along the left edge to interpolate the colors Blue and Green, and again to perform interpolations vertically in the nested for loop along the right edge to interpolate the colors Red and Blue. Once this is peformed, one last interpolation is performed in which is combines the previous interpolations 'InterBlueGreen' and 'InterRedBlue' to interpolate horizontally to combine.
         
         **/
        
        public void bilInter()
        {
           	int grid = userInput();
            BufferedImage image = new BufferedImage(grid,grid,BufferedImage.TYPE_INT_ARGB);
            DisplayBufferedImage(image);
            
            int r = 0xFFFF0000;
            int b = 0xFF0000FF;
            int g = 0xFF00FF00;
            int a = 0xFF000000;
            
            for(int row = 0; row < grid; row++) {
                for(int column = 0; column < grid; column++) {
                    int InterBlueGreen = combo(b,g,column,grid-1);
                    int InterRedBlue = combo(r,a,column,grid-1);
                    int InterHorz = combo(InterBlueGreen,InterRedBlue,row,grid-1);
                    image.setRGB(row,column,InterHorz);
                }
            }
        }
        
        // The method to display our end buffered Image
        public void DisplayBufferedImage(BufferedImage image)
        {
            this.setContentPane(new JLabel(new ImageIcon(image)));
            this.validate();
        }
    }
}
