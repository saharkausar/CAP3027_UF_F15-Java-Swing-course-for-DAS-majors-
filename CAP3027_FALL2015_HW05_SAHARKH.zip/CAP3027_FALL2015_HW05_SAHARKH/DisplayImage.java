import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.io.*;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.*;
import javax.imageio.*;
import javax.swing.*;

public class DisplayImage
{
    
    private static final int WIDTH = 400;
    private static final int HEIGHT = 400;
    
    public static void main( String[] args)
    {
        JFrame frame = new ImageFrame(WIDTH, HEIGHT);
        frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }


    private static class ImageFrame extends JFrame
    {
        // Constructor
        // Initialize the variables
        private static double theta = (int)((Math.PI)/2);
        private static double rho = 1;
        private static double x;
        private static double y;
        private static double beta;
        private static double alpha;
        private static int w;
        private static int h;
        private static int direction;
        private static double tau;
        private static double rhoDelta;
        private static double thetaDelta;
        
        private final JFileChooser chooser;
        public static BufferedImage bufferedImage;
        
        // Sets up the frame's attributes and displays the menu
    
        public ImageFrame(int width, int height){
    
        //frame attributes
        this.setTitle("CAP 3027 2015 - HW05 - Sahar Hussain");
        this.setSize( width, height );
        
        //adds a menu to the frame
        addMenu();
        
        chooser = new JFileChooser();
        chooser.setCurrentDirectory(new File("."));
        //setup the file chooser dialog
    }
        private void addMenu(){
        
            // File Menu Option Display
            JMenu fileMenu = new JMenu("File");
        
            // Creates a JMenuItem for Directed Random Walk plant for the JMenu File if the user perform a random plant walk simulation
            
            JMenuItem openItem = new JMenuItem("Directed random walk plant");
            openItem.addActionListener( new ActionListener()
            {
            public void actionPerformed( ActionEvent event)
                {
                plantWalk();
                }
            }   );
            fileMenu.add( openItem);
        
            // Creates a JMenuItem for the JMenu File if the user wishes to exit the program
            JMenuItem exitItem = new JMenuItem("Exit");
            exitItem.addActionListener( new ActionListener()
                                       {
                public void actionPerformed(ActionEvent event)
                {
                    System.exit( 0 );
                }
            }	);
            fileMenu.add( exitItem);
        
            JMenuBar menuBar = new JMenuBar();
            menuBar.add( fileMenu);
            this.setJMenuBar( menuBar);
        }

        // Methods utilized to gather prompts from the user
    
        public double[] userInput() {
            double[] vars = new double[6];
            
            try {
                //Prompts the user for the image's size (height == width)
                String imgSize = JOptionPane.showInputDialog("Please input the desired image size you would like");
                vars[0] = Double.parseDouble(imgSize);
                //Prompts the user for the number of stems
                String numStems = JOptionPane.showInputDialog("Please input the desired number of stems");
                vars[1] = Double.parseDouble(numStems);
                //Prompts the user for the number of steps per stem
                String numSteps = JOptionPane.showInputDialog("Please input the desired number of steps per stem");
                vars[2] = Double.parseDouble(numSteps);
                //Prompts the user for the transmission probability
                String transmission = JOptionPane.showInputDialog("Please input the desired transmission probability [0.0, 1.0]");
                vars[3] = Double.parseDouble(transmission);
                //Prompts the user for the maximum rotation increment
                String rotation = JOptionPane.showInputDialog("Please input the desired maximum rotation increment [0.0, 1.0]");
                vars[4] = Double.parseDouble(rotation);
                //Prompts the user for the growth segment increment
                String growthSeg = JOptionPane.showInputDialog("Please input the desired growth segment increment");
                vars[5] = Double.parseDouble(growthSeg);
            }
            catch(NumberFormatException e) {
                //Prompts the user for the image's size (height == width)
                JOptionPane.showMessageDialog(this, "Error, please enter the correct input for the desired image size");
                String imgSize = JOptionPane.showInputDialog("Please enter the correct input for the desired image size");
                vars[0] = Double.parseDouble(imgSize);
                //Prompts the user for the number of stems
                JOptionPane.showMessageDialog(this, "Error, please enter the correct input for the desired number of stems");
                String numStems = JOptionPane.showInputDialog("Please enter the correct input for the desired number of stems");
                vars[1] = Double.parseDouble(numStems);
                //Prompts the user for the number of steps per stem
                JOptionPane.showMessageDialog(this, "Error, please enter the correct input for the desired number of steps per stem");
                String numSteps = JOptionPane.showInputDialog("Please enter the correct input for the desired number of steps per stem");
                vars[2] = Double.parseDouble(numSteps);
                //Prompts the user for the transmission probability
                JOptionPane.showMessageDialog(this, "Error, please input the desired transmission probability [0.0, 1.0]");
                String transmission = JOptionPane.showInputDialog("Please input the desired transmission probability [0.0, 1.0]");
                vars[3] = Double.parseDouble(transmission);
                //Prompts the user for the maximum rotation increment
                JOptionPane.showMessageDialog(this, "Error, please input the desired maximum rotation increment [0.0, 1.0]");
                String rotation = JOptionPane.showInputDialog("Please input the desired maximum rotation increment [0.0, 1.0]");
                vars[4] = Double.parseDouble(rotation);
                //Prompts the user for the growth segment increment
                JOptionPane.showMessageDialog(this, "Error, please input the desired growth segment increment");
                String growthSeg = JOptionPane.showInputDialog("Please input the desired growth segment increment");
                vars[5] = Double.parseDouble(growthSeg);
            }
            
            return vars;
        }
        
        /** Method called by the user's selection in the JMenu file selection for the action Event. The program that will 
         created a directed random walk plants simulation based on the directed random walk plant algorithm discussed in class.
         **/
      
        public void plantWalk()
        {
            /** Calls the userInput() method where prompt[0] is the image size, prompt[1] is the number of stems, prompt[2] is the number of steps per stem, prompt[3] is the transmission probability from [0.0, 1.0], prompt[4] is the maxiumum rotation increment from [0.0 , 1.0], prompt[5] is the growth segment increment
             **/
            double[] prompt = userInput();
            
            rhoDelta = prompt[5]; // change in the growth segment length per step (in "pixels")
            thetaDelta = prompt[4]; // maximum change in rotation pet step (in radians)
            
            // Create a new BufferedImage
            bufferedImage = new BufferedImage((int)prompt[0], (int)prompt[0], bufferedImage.TYPE_INT_ARGB);
            Graphics2D g2d = (Graphics2D) bufferedImage.createGraphics();
            
            // Sets the background color to white
            g2d.setColor(Color.WHITE);
            g2d.fill(new Rectangle(0,0,(int)prompt[0],(int)prompt[0]));
            
            // Runs the directed random walk plant algorithm discussed in class following the Random Walk plants handout
            
            g2d.setColor(Color.BLACK);
            w = (int) prompt[0];
            h = w;
            // grows from the point (x,y)
            x = w/2;
            y = h/2;
            
            //Creates the new reflection probability variables
            alpha = prompt[3];
            beta = rho - alpha; // reflection probability
            g2d.drawLine((int)x,(int)(y), (int) x, (int)(y - rho));
            y = y - rho;
            
            // Plots the initial segment for every stem
            for(int row = 0; row < prompt[1]; row++)
            {
                direction = 1;

                for(int column = 1; column < prompt[2]; column++)
                {
                    // Calls the method that determines tau, the virtual's coin bias
                    virtualCoin();
                    // Calls the method that flips the biased coin, to determine which direction to turn next
                    biasedCoin();
                    // Calls the method that computes an offset from end of the old growth segment to the end of the new one
                    offset();
                    // Implements converting to cartesian so we can draw a new line
                    double xPosition_New = rho*Math.cos(theta) + x;
                    double yPosition_New = y - rho*Math.sin(theta);
                    
                    // Draws a growth segment from the old position to the new position
                    g2d.drawLine((int)x,(int)y, (int)xPosition_New, (int) yPosition_New);
                    x = xPosition_New;
                    y = yPosition_New;
                }
                
                // If the stem hasn't finished growing, it goes to step 3 again, if not, it goes back and resets the starting poisition
                x = w/2;
                y = h/2;
                theta = Math.PI/2;
                rho = 1;
            
            // Displays the Image
            displayBufferedImage(bufferedImage);
            }
        }
        
            // Method that computes an offset from end of the old growth segment to the end of the new one
            public void offset()
            {
                rho = ( rho + rhoDelta);
                theta = (theta + ( thetaDelta * Math.random() * direction));
            }
            
            // Calls the method that flips the biased coin, to determine which direction to turn next
            public void biasedCoin()
            {
                double random = Math.random();
                if(random > tau)
                {
                    direction = 1;
                }
                else
                {
                    direction = -1;
                }
            }
            
            // Method that determines tau, the virtual's coin bias
            public void virtualCoin()
            {
                if(direction == -1)
                {
                    tau = alpha;
                }
                else
                {
                    tau = beta;
                }
            }
         
        // The method to display our end buffered Image
    
        public void displayBufferedImage( BufferedImage image)
        {
            this.setContentPane( new JScrollPane(new JLabel(new ImageIcon(image))));
            this.validate();
        }
    }
}