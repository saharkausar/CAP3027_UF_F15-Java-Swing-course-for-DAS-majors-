// Particle object class utilized by our DisplayImage.java in the crystal method to keep track of our unstuck particles

public class Particle {
	private int x = 0;
	private int y = 0;
	String checker = "particleUnstuck";

	Particle(int x, int y) {
		this.x = x;
		this.y = y;
	}
	int getX() {
		return x;
	}
	int getY() {
		return y;
	}
	String getChecker() {
		return checker;
	}
	void setChecker(String checker) {
		this.checker = checker;
	}
	void setXY(int x, int y) {
		this.x = x;
		this.y = y;
	}
}
